import json
import requests

def printLazyPolitics(absentVotingsLimit):
    response = requests.get("https://api-v3.mojepanstwo.pl/dane/poslowie.json?conditions[poslowie.kadencja]=8")
    politicsData = json.loads(response.text)
    for politician in politicsData["Dataobject"]:
        absentVotings = politician["data"]["poslowie.liczba_glosowan_opuszczonych"]
        if absentVotings>absentVotingsLimit:
            print("{} nieobecny/a na {} glosowaniach".format(politician["data"]["ludzie.nazwa"], absentVotings))


printLazyPolitics(1000)


import requests
from bs4 import BeautifulSoup
import sqlite3

db = sqlite3.connect('poslowie.db')
cursor = db.cursor()
cursor.execute("DROP TABLE deputy;")
cursor.execute("CREATE TABLE deputy (name text, born text, list text, votes int)")

baseUrl = "http://www.sejm.gov.pl"
response = requests.get("http://www.sejm.gov.pl/Sejm8.nsf/poslowie.xsp")
deputiesPage = BeautifulSoup(response.text, 'html.parser')

for deputyTag in deputiesPage.select('.deputies'):
    for deputyLinkTag in deputyTag.find_all("a"):
        deputyLink = baseUrl + deputyLinkTag['href']
        deputyResponse = requests.get(deputyLink)
        deputyPage = BeautifulSoup(deputyResponse.text, 'html.parser')
        nameAndSurname = deputyPage.select("#title_content")[0].contents[0].text
        born = deputyPage.select("#urodzony")[0].text
        list = deputyPage.select("#lblLista")[0].next_sibling.text
        votes = deputyPage.select("#lblGlosy")[0].next_sibling.text
        cursor.execute(
            "INSERT INTO deputy (name, born, list, votes) VALUES (?, ?, ? ,?)", (nameAndSurname, born, list, int(votes)))
        print("INSERT INTO deputy VALUES ('{}', '{}', '{}', '{}')".format(nameAndSurname, born, list, int(votes)))
        db.commit()

db.close()

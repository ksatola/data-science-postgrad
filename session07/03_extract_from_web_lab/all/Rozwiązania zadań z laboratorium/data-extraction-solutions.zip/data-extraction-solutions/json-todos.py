import json
import requests

response = requests.get("https://jsonplaceholder.typicode.com/todos")
todos = json.loads(response.text)

for todo in todos:
    for key in todo:
        print("{}: {}, ".format(key, todo[key]), end="")
    print("")

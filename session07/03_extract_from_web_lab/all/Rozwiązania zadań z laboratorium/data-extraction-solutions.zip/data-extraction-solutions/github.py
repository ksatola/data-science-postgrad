import json
import requests
import time

#languageList = json.loads(requests.get("https://api.github.com/languages").text)
#languages = []
#for languageListElement in languageList:
#    languages.append(languageListElement["name"])
languages = {"Java", "C", "C++", "C#", "Javascript", "Python", "PHP", "Go"}

languagesDict = {}
for language in languages:
    projects = json.loads(requests.get("https://api.github.com/search/repositories?q=language:"+language).text)
    time.sleep(1)
    print(projects)
    try:
        languagesDict[language]=projects["total_count"]
    except Exception as e:
        print("Error during retrieving data")

sortedDict = sorted(languagesDict.items(), key = lambda x : x[1], reverse=True)
print(sortedDict)
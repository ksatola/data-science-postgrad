import requests
from bs4 import BeautifulSoup

response = requests.get("https://www.formula1.com")
response.encoding = response.apparent_encoding
pageRootElement = BeautifulSoup(response.text, 'html.parser')


for header in pageRootElement.select('.f1-cc--caption'):
    children = header.children
    for child in children:
        try:
            if "no-margin" in child['class']:
                print(child.text)
        except:
            pass





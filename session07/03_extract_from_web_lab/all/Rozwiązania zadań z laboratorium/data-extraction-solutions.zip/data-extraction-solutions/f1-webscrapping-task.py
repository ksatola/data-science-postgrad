import requests
from bs4 import BeautifulSoup

baseUrl = "https://www.formula1.com"
response = requests.get("https://www.formula1.com/en/results.html/2018/races.html")
response.encoding = response.apparent_encoding
root_html = BeautifulSoup(response.text, 'html.parser')

raceUrls = {}

for race_tag in root_html.select('.resultsarchive-filter-item'):
    for a in race_tag.select('a'):
        if 'race-result.html' in a['href']:
            raceName = a.text.replace('\n', ' ').strip();
            raceUrls[raceName] = baseUrl+a["href"]

# Inna opcja

# for a in root_html.select('.ArchiveLink'):
#     raceName = a.text.replace('\n', ' ').strip()
#     raceUrls[raceName] = baseUrl+a["href"]
#     print(raceName)
#     print(raceUrls[raceName])
#

# Jeszcze inna opcja

# for race_tag in root_html.select('.resultsarchive-table'):
#     for a in race_tag.select('a'):
#         if 'race-result.html' in a['href']:
#             raceName = a.text.replace('\n', ' ').strip();
#             raceUrls[raceName] = baseUrl+a["href"]
#             print(raceName)
#             print(raceUrls[raceName])



for race in raceUrls:
    print("= RACE {}".format(race))
    racePage = BeautifulSoup(requests.get(raceUrls[race]).text, 'html.parser')
    print("  Location: {}".format(racePage.select(".circuit-info")[0].text))
    resultsTableTag = racePage.select('.resultsarchive-table')[0]
    positions = []
    for row in resultsTableTag.select('tbody tr'):
        cells = row.select('td')
        position = cells[1].text
        driver = cells[3].text.replace('\n', ' ').strip()
        print("   Pos: {} - Driver: {}".format(position, driver))












baseUrl = "https://www.formula1.com"
response = requests.get("https://www.formula1.com/en/results.html/2018/races.html")
root_html = BeautifulSoup(response.text, 'html.parser')

raceUrls = {}

for race_tag in root_html.select('.resultsarchive-filter-item'):
    for a in race_tag.select('a'):
        if 'race-result.html' in a['href']:
            raceName = a.text.replace('\n', ' ').strip();
            raceUrls[raceName] = baseUrl+a["href"]

for race in raceUrls:
    print("= RACE {}".format(race))
    racePage = BeautifulSoup(requests.get(raceUrls[race]).text, 'html.parser')
    print("  Location: {}".format(racePage.select(".circuit-info")[0].text))
    resultsTableTag = racePage.select('.resultsarchive-table')[0]
    positions = []
    for row in resultsTableTag.select('tbody tr'):
        cells = row.select('td')
        position = cells[1].text
        driver = cells[3].text.replace('\n', ' ').strip()
        print("   Pos: {} - Driver: {}".format(position, driver))





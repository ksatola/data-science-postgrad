import json
import requests

response = requests.get("http://api.nobelprize.org/v1/prize.json")

prizes = json.loads(response.text)
for prize in prizes["prizes"]:
    if prize["year"]=="2014" and prize["category"]=="peace":
        for laureate in prize["laureates"]:
            print("{} {} {} \n".format(laureate["firstname"], laureate["surname"], laureate["motivation"]))
